# ACCEPTANCE — QA checklist for the port

## Tour
- [ ] "The temple tour" entry starts the guided autopilot; total run ≈ 10:36.
- [ ] All 26 stations ignite in order (8 Mind → stair → 7 Body → stair → 8 Spirit → landing).
- [ ] Station ignition stays synced to the narration audio (seek-resistant: uses the
      audio clock, not wall time).
- [ ] Camera look + zoom work during the tour; movement/jump/fly are suppressed.
- [ ] Tapping the orb ends the tour early → free exploration, no stuck state.
- [ ] Tarot steles show original procedural gold linework — no pasted card images.
- [ ] Mind/Body/Spirit lighting progression reads clearly (gold → amber → indigo).
- [ ] The regular narration playlist never overlaps the tour.
- [ ] Player can stand/walk on the terraces (platform collision works).

## Choice finale
- [ ] At narration end: orb rises, creation animation plays (birds, horses, crystals,
      rings, light beams), prompt appears with all three choices.
- [ ] Each choice shows its exact response line (`SCRIPT.md`).
- [ ] love / undecided → free exploration after a few seconds.
- [ ] rest → soft fade → wanderer is at the Tree of Life, rest begins.

## Tree of Life
- [ ] "The tree of life" start entry arrives at the tree; wisp greets.
- [ ] The tree reads well: trunk, breathing golden canopy, falling leaves, fireflies,
      warm trunk light; mountains hazed on the horizon over water.
- [ ] Near the seat: "Rest beneath the tree" prompt → sitting starts the rest.
- [ ] Camera frames the seated wanderer against the horizon vista.
- [ ] The wisp drifts in close and speaks the four lines in order, then quiet.
- [ ] Move input / stand button / map → rest ends gently ("Go gently."), no stuck camera.

## General
- [ ] `tsc` + production build clean, no console errors.
- [ ] Desktop Chrome/Safari + a mobile viewport (touch controls usable).
- [ ] iOS: audio starts from the user gesture (tour entry tap).
- [ ] No regression to the existing WebGPU temple (`src/world/temple.ts`) or other scenes.
