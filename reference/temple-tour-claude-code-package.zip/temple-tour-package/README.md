# Temple tour + Tree of Life — Claude Code handoff package

Prepared 2026-09-27. This ports a finished feature set (built on the old three.js
base) into the current WebGPU `main` branch of `vy6ycr7tcc-debug/Animation`.

## Start here
1. **`PROMPT.md`** — the full brief for the porting agent. Give this to Claude Code
   along with the package.
2. **`SCRIPT.md`** — every user-facing line, verbatim. Not to be reworded.
3. **`INTEGRATION.md`** — how the features wired into the old `main.ts` (behavior map).
4. **`ACCEPTANCE.md`** — the QA checklist; all boxes must pass.

## Source material
- `patches/tour.patch` — both old-base commits as a patch (logic reference; adapt, don't apply blindly).
- `src/tour/temple.ts` — tour engine (old base).
- `src/tour/tarotArt.ts` — 26 procedural tarot compositions.
- `src/tour/treeOfLife.ts` — the Tree of Life rest scene (old base).
- `content/narration.json` — catalogue with the `TEMPLE` track (105 cues, 26 scenes, 636.08 s).
- `audio/temple-tour.mp3` — tour narration, Aria voice, 4.2 MB.

## Key facts
- Old base: `d646677` → `1279a1e` (tour) → `aa11c2f` (tree of life). Local only, never pushed.
- Target: `origin/main` at `aa88cda7` (observed 2026-09-27) — `three/webgpu` + TSL, ~135 commits ahead.
- The remote already has its own `src/world/temple.ts` (interior hall). Keep it; the tour is separate.
- The love/undecided choice branches stay simple for now — they get expanded later.
- Standing direction: Meta voices only; narration mirrors rather than teaches (no guru posture).
