# INTEGRATION — wiring points in the old `src/main.ts`

The old `main.ts` is ~2,400 lines and shares almost nothing with the WebGPU branch's
`main.ts`, so this is a behavior map, not a merge guide. Port each behavior to the
current architecture's equivalents (start map / portal system, UI overlay system,
camera rig, sit/pose system).

## Tour lifecycle
- **Construction** (old `main.ts:188`): `new TempleTour(scene, narration, player,
  { whisper })`. Needs scene, narration engine, player controller, and a
  whisper/subtitle callback.
- **Start** (`arrive()` TEMPLE branch): entering "The temple tour" hides the
  mobile act/run/fly buttons, calls `tour.begin()`, sets mode to play. The tour
  takes over movement; look/zoom stay live.
- **Choice UI**: `#choice` overlay in `index.html` + CSS in `style.css`. The tour
  raises `onChoice` (show overlay) and `onFinish` (hide overlay, restore buttons).
  Clicking a button calls `tour.choose(key)`.
- **Rest handoff**: when the key is `"rest"`, the old code set a `restPending` flag;
  in `onFinish` it called `treeLife.restFromTour()` — a soft full-screen fade, then
  the player is placed at the tree seat and the rest begins.
- **Early exit**: tapping the guide orb during the tour calls `tour.finish()`;
  the existing "Leave" action also stops the tour.

## Movement suppression
- While `tour.active`: the main loop calls `tour.update(dt)` instead of the normal
  player update. Jump/fly inputs are ignored during the tour.
- While `treeLife.resting`: movement input is zeroed; any move input above a small
  threshold ends the rest (stand up).

## Sitting / rest wiring
- The sit-offer button (`#sit-offer`) is shared: near an archetype being it offers
  "Sit with …"; near the tree seat it offers "Rest beneath the tree" and calls
  `treeLife.beginRest()` instead of the being-sit flow.
- The sit panel (`#sit-panel`, title `#sit-title`) is reused during tree rest with
  the prompt list cleared and the "offer light" button hidden. `#sit-stand` ends
  the rest. Opening the start map also ends it (`arrive()` calls `standUp()` first).
- Camera: the old follow-camera has a `seatedWith: Vector3 | null` — when set, the
  camera frames the player and looks toward that point. The tree sets it to a far
  horizon point so the rest frames the wanderer against the vista.

## Controller
- `platforms: { x, z, r, top }[]` on the player controller: raised discs (the
  temple terraces) that override ground height when the player is above them.
  The tour registers its terrace platforms on begin and clears them on release.

## Narration engine
- `Track` gains optional `scenes?: { t: number; label: string }[]`.
- `Narration.time()` returns the current track position in track seconds from the
  audio clock. The tour polls this every frame to ignite stations.
- The tour's audio file must be registered so `available("TEMPLE")` resolves.

## Start-map entries (old `places()`)
- `{ label: "The temple tour", narration: "TEMPLE", start: <temple entrance> }`
- `{ label: "The tree of life", narration: "TREE", start: <tree seat> }` — the
  `"TREE"` narration id means "no playlist track; the wisp greets instead".
