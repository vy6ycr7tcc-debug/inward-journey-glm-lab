# SCRIPT — every user-facing line, verbatim

Do not reword these. They were written to be non-coercive and non-guru: the
narration mirrors rather than teaches.

## The tour
- On entering: "Follow the light. Look wherever you like — tap the orb to walk on your own."
- On finishing the stations (choice phase): "Stay a while. Let the road settle — then choose, or don't."

## The Choice
- Prompt: "The road is walked. What is not yet waits on your choosing."
- Buttons: "I choose to love" · "I choose to rest" · "I choose not to choose — yet"
- love → "And so it is — the light you carry is the light you are."
- rest → "Then rest. The tree is waiting."
- undecided → "Not choosing is also a choice. The road waits."

## The Tree of Life
- Arriving fresh (wisp): "You found the tree. Sit a while, if you like."
- Sit prompt: "Rest beneath the tree"
- Rest lines, in order (roughly 2.5s / 9s / 15.5s / 22s after sitting):
  1. "There now. The road can wait."
  2. "You don't have to become anything here."
  3. "Rest is also a kind of choosing."
  4. "When you're ready — the light is still there."
- Standing up (wisp): "Go gently."
- Sit panel title: "❋ The tree of life"

## Notes for later (not in this port)
The love and undecided branches will be expanded into fuller scenes later. Keep them
working and simple for now: response line, hold a few seconds, release into free
exploration.
