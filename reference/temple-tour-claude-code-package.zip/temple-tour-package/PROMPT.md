# PROMPT — Port the temple tour + Tree of Life into the WebGPU build

You are working in the **Animation** repo (`vy6ycr7tcc-debug/Animation`), on the current
`main` branch — the **WebGPU** codebase (`three/webgpu` + TSL), ~135 commits ahead of the
old three.js base. This package ports a finished feature set that was built on that old
base. **Do not merge the old branch. Port the features into the current architecture.**

## Source material (this package)

- `patches/tour.patch` — the complete old-base implementation as two commits
  (`1279a1e` temple tour, `aa11c2f` tree of life), based on old-base `d646677`.
  Read it for logic and exact behavior. **Do not apply it blindly**: the target uses
  `three/webgpu`, so adapt imports, materials (TSL where the codebase uses it), and
  the current module layout.
- `src/tour/temple.ts` — the tour engine (old-base version, for reference).
- `src/tour/tarotArt.ts` — 26 procedural tarot compositions (original gold linework).
- `src/tour/treeOfLife.ts` — the Tree of Life rest scene (old-base version).
- `content/narration.json` — full narration catalogue; the only addition is the
  `TEMPLE` track (105 subtitle cues, 26 scene cues, `duration: 636.08`).
- `audio/temple-tour.mp3` — the tour narration audio (4.2 MB). Place it where the
  current build serves audio from (old base used `public/audio/`).
- `SCRIPT.md` — every user-facing line, verbatim. Do not reword.
- `INTEGRATION.md` — the exact wiring points in the old `main.ts`.
- `ACCEPTANCE.md` — the QA checklist. All boxes must pass.

## What to build

### 1. The temple tour (guided autopilot, ~10:36)
- A start-map/portal entry **"The temple tour"**. Entering starts a guided autopilot:
  the wanderer follows a luminous speaking orb along a smooth path through **26 tarot
  stations** (8 Mind → stair → 7 Body → stair → 8 Spirit → landing).
- While the tour runs: **movement input is suppressed, but camera look and zoom stay
  live**. Jump/fly are disabled during the tour. Tapping the orb ends the tour early
  and releases the player into free exploration.
- **Station ignition is driven by the narration audio clock** (`audio.currentTime`),
  never the wall clock — scrubbing/seeking must not desync the stations.
- Visuals: dark-stone terraces over open water with gold trim and stairways;
  holographic tarot steles with the procedural compositions from `tarotArt.ts`
  (recognizable classic compositions redrawn as original linework — **never paste or
  embed card images**); particle halos; Mind = lamp-gold → Body = fire-amber →
  Spirit = indigo/starlight lighting progression.
- The tour needs `platforms` support in the player controller (raised stone the
  wanderer can stand on): see the `controller.ts` hunk in the patch — a list of
  `{x, z, r, top}` discs that override ground height. Adapt to the current controller.
- The regular narration playlist must **not** overlap the tour.

### 2. The Choice (finale)
- When the narration ends, the tour enters a reflective phase: the orb rises and
  brightens, and a creation animation plays (flocks of luminous birds, circling horse
  figures, rising/dissolving crystals, expanding rings, beams of light).
- Prompt (verbatim, `SCRIPT.md`): *"The road is walked. What is not yet waits on
  your choosing."* Three buttons: **I choose to love** / **I choose to rest** /
  **I choose not to choose — yet**. No wrong answer; all three are equally valid.
- **love** → response line, then release into free exploration after ~7 s.
- **undecided** → response line, then release into free exploration after ~7 s.
- **rest** → response line (*"Then rest. The tree is waiting."*), a short beat, then a
  soft fade that carries the wanderer to the Tree of Life and begins the rest scene.
  (The love/undecided branches will be expanded later — keep them working and simple.)

### 3. The Tree of Life (rest scene)
- A start-map entry **"The tree of life"** (❋), independent of the tour.
- A great glowing tree on a coastal hill: trunk + branches + roots, a breathing canopy
  of golden-green light points, falling leaves, fireflies, a warm light in the trunk's
  hollow. Site selection: deterministic search for a hilltop (height 9–24) near the
  temple with open water in view; the seat faces the water with hazed mountain
  silhouettes on the horizon (see `treeOfLife.ts` `findTreeSite`).
- Near the mossy seat the player gets a sit prompt (**"Rest beneath the tree"**).
  Sitting starts the rest: the wanderer sits, the camera settles behind them looking
  out over the horizon, and a **small motherly wisp** (rose-gold, smaller than the
  guide orb) drifts in close and speaks four soft lines (`SCRIPT.md`), then quiet.
- Standing up (move input, stand button, or opening the map) ends the rest gently
  (*"Go gently."*). Arriving fresh, the wisp greets (*"You found the tree. Sit a
  while, if you like."*).
- The wanderer **sits** (existing sit animation). There is no lying-down clip — do
  not fake one by rotating the body.

### 4. Narration plumbing
- Add the `TEMPLE` track to the narration catalogue (merge, don't overwrite).
- The narration engine needs **scene cues** (`scenes: [{t, label}]` per track) and an
  **audio-clock `time()`** (playback position in track seconds). Check the current
  engine first — if it already has equivalents, use them.

## Constraints
- **Do not regress the WebGPU branch.** The remote already has its own
  `src/world/temple.ts` (interior hall, shrines, rites) — keep it. The tour is a
  *separate guided experience*; reconcile, don't replace. If the existing temple and
  the tour both need a start-map entry, both stay.
- Follow the repo's current conventions for WebGPU/TSL, module layout, and asset
  paths. Match the existing visual quality bar.
- Mobile matters: touch controls, and audio must start from a user gesture (iOS).
- Keep the exact script lines (`SCRIPT.md`). Narration voice is Aria
  (`avocado_v2:MAI_01`) — audio file is provided, no re-recording needed.

## Deliverables
1. The ported feature set on a feature branch, building cleanly (`tsc` + production
   build), no console errors.
2. A quick QA pass against `ACCEPTANCE.md` — desktop and a mobile viewport.
3. A short summary of what you changed, what you adapted vs. the old base, and
   anything you had to cut or approximate.
